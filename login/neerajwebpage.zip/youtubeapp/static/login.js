const tl = gsap.timeline()

tl.from(
    ".row",{
        x:"-100%",
        opacity:0,
    }
)

console.log("work")